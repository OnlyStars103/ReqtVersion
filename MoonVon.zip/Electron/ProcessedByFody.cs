﻿using System;

// Token: 0x0200001C RID: 28
internal class ProcessedByFody
{
	// Token: 0x04000075 RID: 117
	internal const string FodyVersion = "6.0.0.0";

	// Token: 0x04000076 RID: 118
	internal const string Costura = "4.1.0.0";
}
