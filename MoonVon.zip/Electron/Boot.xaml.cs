﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Newtonsoft.Json.Linq;

namespace ElectronWPF
{
	// Token: 0x02000002 RID: 2
	public partial class Boot : Window
	{
		// Token: 0x06000002 RID: 2 RVA: 0x00002057 File Offset: 0x00000257
		public Boot()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000003 RID: 3 RVA: 0x0000207C File Offset: 0x0000027C
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			if (!Directory.Exists("bin"))
			{
				Directory.CreateDirectory("bin");
			}
			if (!Directory.Exists("bin\\Icons"))
			{
				Directory.CreateDirectory("bin\\Icons");
			}
			if (!Directory.Exists("scripts"))
			{
				Directory.CreateDirectory("scripts");
			}
			if (!Directory.Exists("workspace"))
			{
				Directory.CreateDirectory("workspace");
			}
			if (!Directory.Exists("autoexec"))
			{
				Directory.CreateDirectory("autoexec");
			}
			this.CheckUpdates = new Thread(new ThreadStart(this.CheckUpdates_DoWork));
			this.CheckUpdates.Start();
		}

		// Token: 0x06000004 RID: 4 RVA: 0x00002120 File Offset: 0x00000320
		private void ChangeStatus(string status, int bar = 0)
		{
			base.Dispatcher.Invoke(delegate()
			{
				this.Label.Content = status;
				this.Bar.Value += (double)bar;
			});
		}

		// Token: 0x06000005 RID: 5 RVA: 0x00002160 File Offset: 0x00000360
		private void CheckUpdates_DoWork()
		{
			this.ChangeStatus("Checking update...", 0);
			if (!File.Exists("bin\\Lua.xshd"))
			{
				this.wc.DownloadFile("https://ryos.best/api/Lua.xshd", "bin\\Lua.xshd");
			}
			string text = this.wc.DownloadString("https://raw.githubusercontent.com/GreenMs02/Electron/master/Games.json");
			bool flag = false;
			if (!File.Exists("bin\\Games.json") || File.ReadAllText("bin\\Games.json") != text)
			{
				flag = true;
				File.WriteAllText("bin\\Games.json", text);
				this.ChangeStatus("Downloading Icons...", 0);
				foreach (KeyValuePair<string, JToken> keyValuePair in JObject.Parse(text))
				{
					string key = keyValuePair.Key;
					string text2 = keyValuePair.Value["image"].ToString();
					string[] array = text2.Split(".".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
					this.wc.DownloadFile(new Uri(text2), "bin\\Icons\\" + key + "." + array[3]);
				}
			}
			bool flag2 = this.CheckDllUpdate();
			if (flag2)
			{
				this.ChangeStatus("Downloading DLL...", 50);
				this.DownloadDLL();
			}
			if (this.CheckSafeInjector())
			{
				ESettings.NormalInjection = false;
				this.ChangeStatus("Downloading Injector...", 50);
				this.DownloadSafeInjector();
			}
			if (!flag2 && !flag)
			{
				this.ChangeStatus("Success", 100);
			}
			else
			{
				this.ChangeStatus("Success", 0);
			}
			Thread.Sleep(1000);
			base.Dispatcher.Invoke(delegate()
			{
				Public.mainWindow.Show();
				base.Hide();
			});
			this.CheckUpdates.Abort();
		}

		// Token: 0x06000006 RID: 6 RVA: 0x00002308 File Offset: 0x00000508
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			Environment.Exit(0);
		}

		// Token: 0x06000007 RID: 7 RVA: 0x00002310 File Offset: 0x00000510
		private bool CheckDllUpdate()
		{
			string[] array = this.wc.DownloadString("https://ryos.best/api/update.jit").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			if (!File.Exists("bin\\version"))
			{
				File.WriteAllText("bin\\version", "0");
			}
			else if (array[0] != string.Empty && File.ReadAllText("bin\\version") != array[0])
			{
				File.WriteAllText("bin\\version", array[0]);
				return true;
			}
			return !File.Exists("ElectronDLL.dll");
		}

		// Token: 0x06000008 RID: 8 RVA: 0x0000239C File Offset: 0x0000059C
		private bool CheckSafeInjector()
		{
			string[] array = this.wc.DownloadString("https://ryos.best/api/edat2.txt").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			if (array[0].Contains("false"))
			{
				return false;
			}
			if (!File.Exists("bin\\versionc"))
			{
				File.WriteAllText("bin\\versionc", "0");
			}
			else if (array[1] != string.Empty && File.ReadAllText("bin\\versionc") != array[1])
			{
				File.WriteAllText("bin\\versionc", array[1]);
				return true;
			}
			ESettings.NormalInjection = false;
			return File.Exists("bin\\ElectronInjector.exe");
		}

		// Token: 0x06000009 RID: 9 RVA: 0x0000243C File Offset: 0x0000063C
		private bool DownloadSafeInjector()
		{
			string[] array = this.wc.DownloadString("https://ryos.best/api/edat2.txt").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			if (!File.Exists("bin\\msvcp140.dll"))
			{
				this.wc.DownloadFile("https://cdn.discordapp.com/attachments/760412369854922762/800014781368238100/msvcp140.dll", "bin\\msvcp140.dll");
			}
			if (!File.Exists("bin\\vcruntime140.dll"))
			{
				this.wc.DownloadFile("https://cdn.discordapp.com/attachments/760412369854922762/800014790104973402/vcruntime140.dll", "bin\\vcruntime140.dll");
			}
			this.wc.DownloadFile(array[2], "bin\\ElectronInjector.exe");
			return File.Exists("bin\\ElectronInjector.exe");
		}

		// Token: 0x0600000A RID: 10 RVA: 0x000024CC File Offset: 0x000006CC
		private bool DownloadDLL()
		{
			string[] array = this.wc.DownloadString("https://ryos.best/api/update.jit").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			this.wc.DownloadFile(array[1], "ElectronDLL.dll");
			return File.Exists("ElectronDLL.dll");
		}

		// Token: 0x04000001 RID: 1
		private string CurrentStatus = "Checking for updates";

		// Token: 0x04000002 RID: 2
		private Thread CheckUpdates;

		// Token: 0x04000003 RID: 3
		private WebClient wc = new WebClient();
	}
}
