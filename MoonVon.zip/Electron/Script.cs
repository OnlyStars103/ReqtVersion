﻿using System;
using System.IO;

namespace ElectronWPF
{
	// Token: 0x0200000B RID: 11
	public class Script
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600002C RID: 44 RVA: 0x00003210 File Offset: 0x00001410
		// (set) Token: 0x0600002D RID: 45 RVA: 0x00003218 File Offset: 0x00001418
		public string ImageURL { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x0600002E RID: 46 RVA: 0x00003221 File Offset: 0x00001421
		// (set) Token: 0x0600002F RID: 47 RVA: 0x00003229 File Offset: 0x00001429
		public string ScriptURL { get; set; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000030 RID: 48 RVA: 0x00003232 File Offset: 0x00001432
		// (set) Token: 0x06000031 RID: 49 RVA: 0x0000323A File Offset: 0x0000143A
		public string CachedScript { get; set; }

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000032 RID: 50 RVA: 0x00003243 File Offset: 0x00001443
		// (set) Token: 0x06000033 RID: 51 RVA: 0x0000324B File Offset: 0x0000144B
		public Stream CachedImage { get; set; }
	}
}
