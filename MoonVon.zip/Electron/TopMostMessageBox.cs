﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ElectronWPF
{
	// Token: 0x02000017 RID: 23
	public static class TopMostMessageBox
	{
		// Token: 0x06000080 RID: 128 RVA: 0x00004B5B File Offset: 0x00002D5B
		public static DialogResult Show(string message)
		{
			return TopMostMessageBox.Show(message, string.Empty, MessageBoxButtons.OK);
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00004B69 File Offset: 0x00002D69
		public static DialogResult Show(string message, string title)
		{
			return TopMostMessageBox.Show(message, title, MessageBoxButtons.OK);
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00004B74 File Offset: 0x00002D74
		public static DialogResult Show(string message, string title, MessageBoxButtons buttons)
		{
			Form form = new Form();
			form.Size = new Size(1, 1);
			form.StartPosition = FormStartPosition.Manual;
			Rectangle virtualScreen = SystemInformation.VirtualScreen;
			form.Location = new Point(virtualScreen.Bottom + 10, virtualScreen.Right + 10);
			form.Show();
			form.Focus();
			form.BringToFront();
			form.TopMost = true;
			DialogResult result = MessageBox.Show(form, message, title, buttons);
			form.Dispose();
			return result;
		}
	}
}
