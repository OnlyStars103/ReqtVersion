﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("ElectronWPF")]
[assembly: AssemblyDescription("Electron Copyright")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Electron")]
[assembly: AssemblyProduct("ElectronWPF")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("(Co)")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyFileVersion("1.0.0.0")]
