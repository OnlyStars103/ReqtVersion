﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace ElectronWPF.Properties
{
	// Token: 0x02000019 RID: 25
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000085 RID: 133 RVA: 0x000025D2 File Offset: 0x000007D2
		internal Resources()
		{
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000086 RID: 134 RVA: 0x00004C13 File Offset: 0x00002E13
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("ElectronWPF.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000087 RID: 135 RVA: 0x00004C3F File Offset: 0x00002E3F
		// (set) Token: 0x06000088 RID: 136 RVA: 0x00004C46 File Offset: 0x00002E46
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x0400006D RID: 109
		private static ResourceManager resourceMan;

		// Token: 0x0400006E RID: 110
		private static CultureInfo resourceCulture;
	}
}
