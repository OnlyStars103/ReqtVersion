﻿using System;

namespace ElectronWPF
{
	// Token: 0x02000018 RID: 24
	internal class Public
	{
		// Token: 0x04000069 RID: 105
		internal static Settings settings = new Settings();

		// Token: 0x0400006A RID: 106
		internal static ScriptHub scriptHub = new ScriptHub();

		// Token: 0x0400006B RID: 107
		internal static GamesHub gamesHub = new GamesHub();

		// Token: 0x0400006C RID: 108
		internal static MainWindow mainWindow = new MainWindow();
	}
}
