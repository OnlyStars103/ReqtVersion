﻿using System;
using System.Runtime.InteropServices;

namespace ElectronWPF
{
	// Token: 0x02000015 RID: 21
	internal class Injector
	{
		// Token: 0x06000075 RID: 117
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern int CloseHandle(IntPtr hObject);

		// Token: 0x06000076 RID: 118
		[DllImport("kernel32.dll")]
		public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		// Token: 0x06000077 RID: 119
		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x06000078 RID: 120
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

		// Token: 0x06000079 RID: 121
		[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		// Token: 0x0600007A RID: 122
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

		// Token: 0x0600007B RID: 123
		[DllImport("kernel32.dll")]
		public static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

		// Token: 0x04000061 RID: 97
		public const int PROCESS_CREATE_THREAD = 2;

		// Token: 0x04000062 RID: 98
		public const int PROCESS_QUERY_INFORMATION = 1024;

		// Token: 0x04000063 RID: 99
		public const int PROCESS_VM_OPERATION = 8;

		// Token: 0x04000064 RID: 100
		public const int PROCESS_VM_WRITE = 32;

		// Token: 0x04000065 RID: 101
		public const int PROCESS_VM_READ = 16;

		// Token: 0x04000066 RID: 102
		public const uint MEM_COMMIT = 4096U;

		// Token: 0x04000067 RID: 103
		public const uint MEM_RESERVE = 8192U;

		// Token: 0x04000068 RID: 104
		public const uint PAGE_READWRITE = 4U;
	}
}
