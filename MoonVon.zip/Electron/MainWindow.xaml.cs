﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Xml;
using DiscordRPC;
using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;

namespace ElectronWPF
{
	// Token: 0x0200000F RID: 15
	public partial class MainWindow : Window, IStyleConnector
	{
		// Token: 0x06000045 RID: 69 RVA: 0x00003908 File Offset: 0x00001B08
		public MainWindow()
		{
			this.InitializeComponent();
			AppDomain.CurrentDomain.AssemblyResolve += this.CurrentDomain_AssemblyResolve;
			this.AttachedLbl.Visibility = Visibility.Hidden;
			this.ProgressLabel.Visibility = Visibility.Hidden;
			this.timer = new System.Windows.Forms.Timer();
			this.timer.Tick += this.Timer_Tick;
			this.timer.Interval = 500;
			this.timer.Start();
		}

		// Token: 0x06000046 RID: 70 RVA: 0x000039A1 File Offset: 0x00001BA1
		private void Timer_Tick(object sender, EventArgs e)
		{
			if (Exec.namedPipeExist("EPipe"))
			{
				this.AttachedLbl.Visibility = Visibility.Visible;
				return;
			}
			if (this.AttachedLbl.Visibility == Visibility.Visible)
			{
				this.AttachedLbl.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000039D8 File Offset: 0x00001BD8
		private Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
		{
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			string requiredDllName = string.Format("${0}.dll", new AssemblyName(args.Name));
			string text = (from s in executingAssembly.GetManifestResourceNames()
			where s.EndsWith(requiredDllName)
			select s).FirstOrDefault<string>();
			if (text != null)
			{
				using (Stream manifestResourceStream = executingAssembly.GetManifestResourceStream(text))
				{
					if (manifestResourceStream == null)
					{
						return null;
					}
					byte[] array = new byte[manifestResourceStream.Length];
					manifestResourceStream.Read(array, 0, array.Length);
					return Assembly.Load(array);
				}
			}
			return null;
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003A84 File Offset: 0x00001C84
		public void Tabs(System.Windows.Controls.TabControl tabs, string Name = "New Tab", string Text = "")
		{
			TabItem tabItem = new TabItem();
			tabItem.Height = 24.0;
			tabItem.Width = 60.0;
			this.Tabcontrol.Items.Add(tabItem);
			TextEditor textEditor = new TextEditor();
			textEditor.FontFamily = new FontFamily("Consolas");
			textEditor.FontSize = 13.333;
			textEditor.Background = new SolidColorBrush(Color.FromRgb(21, 21, 21));
			textEditor.LineNumbersForeground = new SolidColorBrush(Color.FromRgb(150, 150, 150));
			textEditor.Foreground = new SolidColorBrush(Color.FromRgb(235, 235, 235));
			textEditor.ShowLineNumbers = true;
			textEditor.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			textEditor.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			tabItem.Content = textEditor;
			tabItem.Header = Name;
			tabItem.IsSelected = true;
			textEditor.Options.EnableHyperlinks = false;
			textEditor.Options.ShowSpaces = false;
			textEditor.Options.ShowTabs = false;
			textEditor.Text = Text;
			textEditor.TextArea.TextView.ElementGenerators.Add(new LongLines());
			textEditor.ContextMenu = new System.Windows.Controls.ContextMenu
			{
				Items = 
				{
					new System.Windows.Controls.MenuItem().Command = ApplicationCommands.Undo,
					new System.Windows.Controls.MenuItem().Command = ApplicationCommands.Redo,
					new Separator(),
					new System.Windows.Controls.MenuItem().Command = ApplicationCommands.Cut,
					new System.Windows.Controls.MenuItem().Command = ApplicationCommands.Copy,
					new System.Windows.Controls.MenuItem().Command = ApplicationCommands.Paste
				}
			};
			if (File.Exists("./bin/Lua.xshd"))
			{
				FileStream fileStream = File.OpenRead("./bin/Lua.xshd");
				XmlTextReader xmlTextReader = new XmlTextReader(fileStream);
				textEditor.SyntaxHighlighting = HighlightingLoader.Load(xmlTextReader, HighlightingManager.Instance);
				xmlTextReader.Close();
				fileStream.Close();
			}
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00003C9F File Offset: 0x00001E9F
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.Tabcontrol.Items.Count != 1)
			{
				this.Tabcontrol.Items.Remove(this.Tabcontrol.SelectedItem);
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00003CD1 File Offset: 0x00001ED1
		private void AddTabButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.Tabcontrol.Items.Count != 7)
			{
				this.Tabs(this.Tabcontrol, "New Tab", "");
			}
		}

		// Token: 0x0600004B RID: 75 RVA: 0x000032BA File Offset: 0x000014BA
		private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.Left)
			{
				base.DragMove();
			}
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00003CFE File Offset: 0x00001EFE
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			this.loop.Abort();
			Environment.Exit(0);
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00003D11 File Offset: 0x00001F11
		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00003D1A File Offset: 0x00001F1A
		private void Button_Click_2(object sender, RoutedEventArgs e)
		{
			Public.settings.Show();
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00003D26 File Offset: 0x00001F26
		private void Button_Click_3(object sender, RoutedEventArgs e)
		{
			Public.scriptHub.Show();
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00003D32 File Offset: 0x00001F32
		private void Button_Click_4(object sender, RoutedEventArgs e)
		{
			Public.gamesHub.Show();
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00003D40 File Offset: 0x00001F40
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			MainWindow.<Window_Loaded>d__16 <Window_Loaded>d__;
			<Window_Loaded>d__.<>4__this = this;
			<Window_Loaded>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Window_Loaded>d__.<>1__state = -1;
			<Window_Loaded>d__.<>t__builder.Start<MainWindow.<Window_Loaded>d__16>(ref <Window_Loaded>d__);
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00003D78 File Offset: 0x00001F78
		private void loop3()
		{
			if (!ESettings.RPC)
			{
				this.client.ClearPresence();
				this.client.Invoke();
			}
			else
			{
				if (!this.client.CurrentPresence || this.client.CurrentPresence == null)
				{
					this.client.SetPresence(new RichPresence
					{
						Details = "Electron Winning",
						State = "discord.io/EJIT",
						Assets = new Assets
						{
							LargeImageKey = "electron3"
						}
					});
				}
				if (this.client != null)
				{
					this.client.Invoke();
				}
			}
			Thread.Sleep(1000);
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00003E20 File Offset: 0x00002020
		private void AddScripts()
		{
			this.ListBox.Items.Clear();
			foreach (FileInfo fileInfo in new DirectoryInfo("scripts").GetFiles("*.*"))
			{
				this.ListBox.Items.Add(fileInfo.Name);
			}
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00003E7C File Offset: 0x0000207C
		public static T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
		{
			int i = 0;
			while (i < VisualTreeHelper.GetChildrenCount(parent))
			{
				DependencyObject child = VisualTreeHelper.GetChild(parent, i);
				T result;
				if (child != null && child is T)
				{
					result = (T)((object)child);
				}
				else
				{
					T t = MainWindow.FindVisualChild<T>(child);
					if (t == null)
					{
						i++;
						continue;
					}
					result = t;
				}
				return result;
			}
			return default(T);
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00003EE0 File Offset: 0x000020E0
		private void Button_Click_5(object sender, RoutedEventArgs e)
		{
			MainWindow.FindVisualChild<TextEditor>(this.Tabcontrol);
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				CheckFileExists = true,
				Filter = "All files (*.*)|*.*"
			};
			openFileDialog.Title = "Electron | Open File";
			if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				Exec.ExecuteScript(File.ReadAllText(openFileDialog.FileName));
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00003F35 File Offset: 0x00002135
		private void Button_Click_6(object sender, RoutedEventArgs e)
		{
			MainWindow.FindVisualChild<TextEditor>(this.Tabcontrol).Clear();
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00003F48 File Offset: 0x00002148
		private void Button_Click_7(object sender, RoutedEventArgs e)
		{
			MainWindow.FindVisualChild<TextEditor>(this.Tabcontrol);
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				CheckFileExists = true,
				Filter = "All files (*.*)|*.*"
			};
			openFileDialog.Title = "Electron | Open File";
			if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				this.Tabs(this.Tabcontrol, Path.GetFileName(openFileDialog.FileName), File.ReadAllText(openFileDialog.FileName));
			}
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00003FB0 File Offset: 0x000021B0
		private void MenuItem2_OnClick(object sender, RoutedEventArgs e)
		{
			TextEditor textEditor = MainWindow.FindVisualChild<TextEditor>(this.Tabcontrol);
			if (this.ListBox.SelectedIndex != -1)
			{
				textEditor.Text = File.ReadAllText(".\\scripts\\" + this.ListBox.SelectedItem.ToString());
			}
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00003FFC File Offset: 0x000021FC
		private void MenuItem1_OnClick(object sender, RoutedEventArgs e)
		{
			if (this.ListBox.SelectedIndex != -1)
			{
				Exec.ExecuteScript(File.ReadAllText("scripts\\" + this.ListBox.SelectedItem.ToString()));
			}
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00004030 File Offset: 0x00002230
		private void MenuItem3_OnClick(object sender, RoutedEventArgs e)
		{
			this.AddScripts();
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00004038 File Offset: 0x00002238
		private void ListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.Left && this.ListBox.SelectedIndex != -1)
			{
				string path = "scripts\\" + this.ListBox.SelectedItem.ToString();
				this.Tabs(this.Tabcontrol, Path.GetFileName(path), File.ReadAllText(path));
			}
		}

		// Token: 0x0600005C RID: 92 RVA: 0x0000408E File Offset: 0x0000228E
		private void Button_Click_8(object sender, RoutedEventArgs e)
		{
			this.Tabcontrol.Items.Clear();
			this.Tabs(this.Tabcontrol, "New Tab", "");
		}

		// Token: 0x0600005D RID: 93 RVA: 0x000040B6 File Offset: 0x000022B6
		private void Button_Click_9(object sender, RoutedEventArgs e)
		{
			Exec.ExecuteScript(MainWindow.FindVisualChild<TextEditor>(this.Tabcontrol).Text);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x000040D0 File Offset: 0x000022D0
		private bool CheckDllUpdate()
		{
			string[] array = new WebClient().DownloadString("https://ryos.best/api/update.jit").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			if (!File.Exists("bin\\version"))
			{
				File.WriteAllText("bin\\version", "0");
			}
			else if (array[0] != string.Empty && File.ReadAllText("bin\\version") != array[0])
			{
				File.WriteAllText("bin\\version", array[0]);
				return true;
			}
			return !File.Exists("ElectronDLL.dll");
		}

		// Token: 0x0600005F RID: 95 RVA: 0x0000415C File Offset: 0x0000235C
		private bool DownloadDLL()
		{
			WebClient webClient = new WebClient();
			string[] array = webClient.DownloadString("https://ryos.best/api/update.jit").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			webClient.DownloadProgressChanged += delegate(object sender, DownloadProgressChangedEventArgs e)
			{
				base.Dispatcher.Invoke(delegate()
				{
					this.ProgressLabel.Content = string.Format("Downloading DLL ({0}%)", e.ProgressPercentage);
				});
			};
			webClient.DownloadFileCompleted += delegate(object sender, AsyncCompletedEventArgs e)
			{
				base.Dispatcher.Invoke(delegate()
				{
					this.ProgressLabel.Visibility = Visibility.Hidden;
				});
				this.Inject();
			};
			this.ProgressLabel.Content = "Downloading DLL(0%)";
			this.ProgressLabel.Visibility = Visibility.Visible;
			webClient.DownloadFileAsync(new Uri(array[1]), "ElectronDLL.dll");
			return File.Exists("ElectronDLL.dll");
		}

		// Token: 0x06000060 RID: 96 RVA: 0x000041E6 File Offset: 0x000023E6
		private void Button_Click_10(object sender, RoutedEventArgs e)
		{
			if (this.CheckDllUpdate() || !File.Exists(this.dllName))
			{
				this.DownloadDLL();
				return;
			}
			this.Inject();
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0000420C File Offset: 0x0000240C
		private void Inject()
		{
			if (ESettings.NormalInjection || !File.Exists("bin\\ElectronInjector.exe"))
			{
				IntPtr procAddress = Injector.GetProcAddress(Injector.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
				foreach (Process process in Process.GetProcessesByName("RobloxPlayerBeta"))
				{
					IntPtr intPtr = Injector.OpenProcess(1082, false, process.Id);
					IntPtr intPtr2 = Injector.VirtualAllocEx(intPtr, IntPtr.Zero, (uint)((this.dllName.Length + 1) * Marshal.SizeOf(typeof(char))), 12288U, 4U);
					UIntPtr uintPtr;
					Injector.WriteProcessMemory(intPtr, intPtr2, Encoding.Default.GetBytes(this.dllName), (uint)((this.dllName.Length + 1) * Marshal.SizeOf(typeof(char))), out uintPtr);
					Injector.CreateRemoteThread(intPtr, IntPtr.Zero, 0U, procAddress, intPtr2, 0U, IntPtr.Zero);
					Injector.CloseHandle(intPtr);
				}
				return;
			}
			foreach (Process process2 in Process.GetProcessesByName("RobloxPlayerBeta"))
			{
				new Process
				{
					StartInfo = new ProcessStartInfo
					{
						WindowStyle = ProcessWindowStyle.Hidden,
						FileName = "bin\\ElectronInjector.exe",
						Arguments = string.Format("{0} \"{1}\"", process2.Id.ToString(), Path.GetFullPath("ElectronDLL.dll"))
					}
				}.Start();
			}
		}

		// Token: 0x06000064 RID: 100 RVA: 0x000045FF File Offset: 0x000027FF
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((System.Windows.Controls.Button)target).Click += this.CloseButton_Click;
				return;
			}
			if (connectionId != 3)
			{
				return;
			}
			((System.Windows.Controls.Button)target).Click += this.AddTabButton_Click;
		}

		// Token: 0x0400004C RID: 76
		private System.Windows.Forms.Timer timer;

		// Token: 0x0400004D RID: 77
		private string dllName = System.Windows.Forms.Application.StartupPath + "\\ElectronDLL.dll";

		// Token: 0x0400004E RID: 78
		public DiscordRpcClient client;

		// Token: 0x0400004F RID: 79
		public Thread loop;

        private void Tabcontrol_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
