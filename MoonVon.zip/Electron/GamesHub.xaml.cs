﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Newtonsoft.Json.Linq;

namespace ElectronWPF
{
	// Token: 0x02000005 RID: 5
	public partial class GamesHub : Window
	{
		// Token: 0x06000012 RID: 18 RVA: 0x0000261E File Offset: 0x0000081E
		public GamesHub()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002642 File Offset: 0x00000842
		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			base.Hide();
		}

		// Token: 0x06000014 RID: 20 RVA: 0x0000264A File Offset: 0x0000084A
		private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
		{
			base.DragMove();
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002654 File Offset: 0x00000854
		private void MainBorder_Loaded(object sender, RoutedEventArgs e)
		{
			GamesHub.<MainBorder_Loaded>d__6 <MainBorder_Loaded>d__;
			<MainBorder_Loaded>d__.<>4__this = this;
			<MainBorder_Loaded>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<MainBorder_Loaded>d__.<>1__state = -1;
			<MainBorder_Loaded>d__.<>t__builder.Start<GamesHub.<MainBorder_Loaded>d__6>(ref <MainBorder_Loaded>d__);
		}

		// Token: 0x06000016 RID: 22 RVA: 0x0000268C File Offset: 0x0000088C
		private void BackgroundTask()
		{
			JObject jobject = JObject.Parse(File.ReadAllText("bin\\Games.json"));
			int num = 1;
			foreach (KeyValuePair<string, JToken> keyValuePair in jobject)
			{
				string name = "img" + num.ToString();
				JToken value = keyValuePair.Value;
				string[] array = value["image"].ToString().Split(".".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
				Script script = new Script();
				script.ImageURL = value["image"].ToString();
				script.ScriptURL = value["script"].ToString();
				script.CachedImage = null;
				script.CachedScript = null;
				MemoryStream uwu = new MemoryStream(File.ReadAllBytes("bin\\Icons\\" + keyValuePair.Key + "." + array[3]));
				base.Dispatcher.Invoke(delegate()
				{
					BitmapImage bitmapImage = new BitmapImage
					{
						CacheOption = BitmapCacheOption.OnLoad
					};
					bitmapImage.BeginInit();
					bitmapImage.StreamSource = uwu;
					bitmapImage.EndInit();
					Image image = (Image)this.FindName(name);
					image.Source = bitmapImage;
					image.MouseDown += this.Image_MouseDown;
					image.Stretch = Stretch.UniformToFill;
				});
				this.Scripts[name] = script;
				num++;
			}
			this.thread.Abort();
		}

		// Token: 0x06000017 RID: 23 RVA: 0x000027EC File Offset: 0x000009EC
		private void Image_MouseDown(object sender, MouseButtonEventArgs e)
		{
			Image image = (Image)sender;
			string text = this.Scripts[image.Name].CachedScript;
			if (this.Scripts[image.Name].CachedScript == null)
			{
				text = this.wc.DownloadString(this.Scripts[image.Name].ScriptURL);
				this.Scripts[image.Name].CachedScript = text;
			}
			Exec.ExecuteScript(text);
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002642 File Offset: 0x00000842
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			base.Hide();
		}

		// Token: 0x0400000C RID: 12
		private Dictionary<string, Script> Scripts = new Dictionary<string, Script>();

		// Token: 0x0400000D RID: 13
		private Thread thread;

		// Token: 0x0400000E RID: 14
		private WebClient wc = new WebClient();
	}
}
