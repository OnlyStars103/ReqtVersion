﻿using System;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace ElectronWPF
{
	// Token: 0x02000014 RID: 20
	internal class Exec
	{
		// Token: 0x06000071 RID: 113 RVA: 0x000049C8 File Offset: 0x00002BC8
		public static void ExecuteScript(string Script)
		{
			if (Exec.namedPipeExist("EPipe"))
			{
				using (NamedPipeClientStream namedPipeClientStream = new NamedPipeClientStream(".", "EPipe", PipeDirection.Out))
				{
					namedPipeClientStream.Connect();
					using (StreamWriter streamWriter = new StreamWriter(namedPipeClientStream, Encoding.Default, 999999))
					{
						streamWriter.Write(Script);
						streamWriter.Dispose();
					}
					namedPipeClientStream.Dispose();
				}
				return;
			}
			if (File.Exists("ElectronDLL.dll"))
			{
				MessageBox.Show("Please attach!", "NamedPipeDoesntExist", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
			MessageBox.Show("Please turn off your antivirus!", "DLLDoesntExist", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00004A84 File Offset: 0x00002C84
		public static bool namedPipeExist(string pipeName)
		{
			bool result;
			try
			{
				if (!Exec.WaitNamedPipe(Path.GetFullPath(string.Format("\\\\.\\pipe\\{0}", pipeName)), 0))
				{
					int lastWin32Error = Marshal.GetLastWin32Error();
					if (lastWin32Error == 0)
					{
						result = false;
						return result;
					}
					if (lastWin32Error == 2)
					{
						result = false;
						return result;
					}
				}
				result = true;
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000073 RID: 115
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool WaitNamedPipe(string name, int timeout);
	}
}
