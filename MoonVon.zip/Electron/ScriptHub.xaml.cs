﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Newtonsoft.Json.Linq;

namespace ElectronWPF
{
	// Token: 0x02000008 RID: 8
	public partial class ScriptHub : Window
	{
		// Token: 0x0600001F RID: 31 RVA: 0x00002C0C File Offset: 0x00000E0C
		public ScriptHub()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000020 RID: 32 RVA: 0x0000264A File Offset: 0x0000084A
		private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
		{
			base.DragMove();
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00002642 File Offset: 0x00000842
		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			base.Hide();
		}

		// Token: 0x06000022 RID: 34 RVA: 0x00002C3C File Offset: 0x00000E3C
		private void MainBorder_Loaded(object sender, RoutedEventArgs e)
		{
			ScriptHub.<MainBorder_Loaded>d__7 <MainBorder_Loaded>d__;
			<MainBorder_Loaded>d__.<>4__this = this;
			<MainBorder_Loaded>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<MainBorder_Loaded>d__.<>1__state = -1;
			<MainBorder_Loaded>d__.<>t__builder.Start<ScriptHub.<MainBorder_Loaded>d__7>(ref <MainBorder_Loaded>d__);
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00002C74 File Offset: 0x00000E74
		private void BackgroundTask()
		{
			this.Cached = this.wc.DownloadString("https://raw.githubusercontent.com/GreenMs02/Electron/master/Scripthub.json");
			JObject jobject = JObject.Parse(this.Cached);
			int num = 1;
			foreach (KeyValuePair<string, JToken> keyValuePair in jobject)
			{
				string name = "img" + num.ToString();
				JToken value = keyValuePair.Value;
				Script script = new Script();
				script.ImageURL = value["image"].ToString();
				script.ScriptURL = value["script"].ToString();
				script.CachedImage = null;
				script.CachedScript = null;
				MemoryStream uwu = new MemoryStream(this.wc.DownloadData(script.ImageURL));
				base.Dispatcher.Invoke(delegate()
				{
					BitmapImage bitmapImage = new BitmapImage
					{
						CacheOption = BitmapCacheOption.OnLoad
					};
					bitmapImage.BeginInit();
					bitmapImage.StreamSource = uwu;
					bitmapImage.EndInit();
					Image image = (Image)this.FindName(name);
					image.Source = bitmapImage;
					image.MouseDown += this.Image_MouseDown;
					image.Stretch = Stretch.UniformToFill;
				});
				this.Scripts[name] = script;
				num++;
			}
			base.Dispatcher.Invoke(delegate()
			{
				this.AttachedLbl.Visibility = Visibility.Collapsed;
			});
			this.thread.Abort();
		}

		// Token: 0x06000024 RID: 36 RVA: 0x00002DC0 File Offset: 0x00000FC0
		private void Image_MouseDown(object sender, MouseButtonEventArgs e)
		{
			Image image = (Image)sender;
			string text = this.Scripts[image.Name].CachedScript;
			if (this.Scripts[image.Name].CachedScript == null)
			{
				text = this.wc.DownloadString(this.Scripts[image.Name].ScriptURL);
				this.Scripts[image.Name].CachedScript = text;
			}
			Exec.ExecuteScript(text);
		}

		// Token: 0x04000020 RID: 32
		private WebClient wc = new WebClient();

		// Token: 0x04000021 RID: 33
		private string Cached = string.Empty;

		// Token: 0x04000022 RID: 34
		private Dictionary<string, Script> Scripts = new Dictionary<string, Script>();

		// Token: 0x04000023 RID: 35
		private Thread thread;
	}
}
