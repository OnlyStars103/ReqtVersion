﻿using System;
using ICSharpCode.AvalonEdit.Document;
using ICSharpCode.AvalonEdit.Rendering;

namespace ElectronWPF
{
	// Token: 0x02000016 RID: 22
	internal class LongLines : VisualLineElementGenerator
	{
		// Token: 0x0600007D RID: 125 RVA: 0x00004AE0 File Offset: 0x00002CE0
		public override int GetFirstInterestedOffset(int startOffset)
		{
			DocumentLine lastDocumentLine = base.CurrentContext.VisualLine.LastDocumentLine;
			if (lastDocumentLine.Length > 2000)
			{
				int num = lastDocumentLine.Offset + 2000 - 100 - "...".Length;
				if (startOffset <= num)
				{
					return num;
				}
			}
			return -1;
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00004B2D File Offset: 0x00002D2D
		public override VisualLineElement ConstructElement(int offset)
		{
			return new FormattedTextElement("...", base.CurrentContext.VisualLine.LastDocumentLine.EndOffset - offset - 100);
		}
	}
}
