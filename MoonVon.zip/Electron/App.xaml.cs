﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace ElectronWPF
{
	// Token: 0x0200000E RID: 14
	public partial class App : Application
	{
	}
}
