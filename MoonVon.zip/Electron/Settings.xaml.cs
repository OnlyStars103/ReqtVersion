﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ElectronWPF
{
	// Token: 0x0200000C RID: 12
	public partial class Settings : Window
	{
		// Token: 0x06000035 RID: 53 RVA: 0x00003254 File Offset: 0x00001454
		public Settings()
		{
			this.InitializeComponent();
			this.coLabel.Content = "- Owner and exploit Developer";
			this.zagLabel.Content = "- UI Developer";
			this.riceLabel.Content = "- The other UI Developer";
			base.Topmost = true;
		}

		// Token: 0x06000036 RID: 54 RVA: 0x000032BA File Offset: 0x000014BA
		private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.Left)
			{
				base.DragMove();
			}
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00002642 File Offset: 0x00000842
		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			base.Hide();
		}

		// Token: 0x06000038 RID: 56 RVA: 0x000032CC File Offset: 0x000014CC
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			foreach (Process process in Process.GetProcesses())
			{
				if (process.ProcessName.Contains("RobloxPlayerBeta"))
				{
					process.Kill();
				}
			}
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00003309 File Offset: 0x00001509
		private void Button_Click_2(object sender, RoutedEventArgs e)
		{
			Process.Start("https://discord.io/EJIT");
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00003318 File Offset: 0x00001518
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00003350 File Offset: 0x00001550
		private void CheckBox_Checked(object sender, RoutedEventArgs e)
		{
			bool? isChecked = this.TopMostbox.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				base.Topmost = true;
				Public.mainWindow.Topmost = true;
				Public.scriptHub.Topmost = true;
				Public.gamesHub.Topmost = true;
			}
			isChecked = this.TopMostbox.IsChecked;
			flag = false;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				base.Topmost = false;
				Public.mainWindow.Topmost = false;
				Public.scriptHub.Topmost = false;
				Public.gamesHub.Topmost = false;
			}
		}

		// Token: 0x0600003C RID: 60 RVA: 0x000033F4 File Offset: 0x000015F4
		private void RPCbox_Checked(object sender, RoutedEventArgs e)
		{
			ESettings.RPC = this.INJBox.IsChecked.GetValueOrDefault();
		}

		// Token: 0x0600003D RID: 61 RVA: 0x0000341C File Offset: 0x0000161C
		private void INJBox_Checked(object sender, RoutedEventArgs e)
		{
			ESettings.NormalInjection = this.INJBox.IsChecked.GetValueOrDefault();
		}

		// Token: 0x0400003A RID: 58
		private DispatcherTimer topmost = new DispatcherTimer();

		// Token: 0x0400003B RID: 59
		private DispatcherTimer rpc = new DispatcherTimer();
	}
}
