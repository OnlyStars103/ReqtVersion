﻿using System;

namespace ElectronWPF
{
	// Token: 0x02000004 RID: 4
	internal class ESettings
	{
		// Token: 0x0400000A RID: 10
		internal static bool NormalInjection = true;

		// Token: 0x0400000B RID: 11
		internal static bool RPC = true;
	}
}
